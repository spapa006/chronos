import { AgeResult } from '../types.ts';

export const calculateAge = (birthDate: Date): AgeResult => {
  const now = new Date();
  
  // Normalize dates to start of day to avoid time zone issues on calculation
  const birth = new Date(birthDate.getFullYear(), birthDate.getMonth(), birthDate.getDate());
  const current = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  let years = current.getFullYear() - birth.getFullYear();
  let months = current.getMonth() - birth.getMonth();
  let days = current.getDate() - birth.getDate();

  // Adjust if current month/day is before birth month/day
  if (months < 0 || (months === 0 && days < 0)) {
    years--;
    months += 12;
  }

  if (days < 0) {
    const prevMonthLastDay = new Date(current.getFullYear(), current.getMonth(), 0).getDate();
    days += prevMonthLastDay;
    months--;
  }

  // Totals
  const diffTime = Math.abs(current.getTime() - birth.getTime());
  const totalDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const totalWeeks = Math.floor(totalDays / 7);
  const totalMonths = (years * 12) + months;
  const totalHours = totalDays * 24;

  // Next Birthday
  const nextBirthdayYear = (now.getMonth() > birth.getMonth() || (now.getMonth() === birth.getMonth() && now.getDate() >= birth.getDate())) 
    ? now.getFullYear() + 1 
    : now.getFullYear();
  
  const nextBirthdayDate = new Date(nextBirthdayYear, birth.getMonth(), birth.getDate());
  const diffNext = nextBirthdayDate.getTime() - current.getTime();
  const daysToNext = Math.ceil(diffNext / (1000 * 60 * 60 * 24));
  
  // Calculate months and days remaining for next birthday
  let monthsToNext = nextBirthdayDate.getMonth() - current.getMonth();
  let remainingDaysToNext = nextBirthdayDate.getDate() - current.getDate();

  if (remainingDaysToNext < 0) {
      monthsToNext -= 1;
      const prevMonth = new Date(nextBirthdayDate.getFullYear(), nextBirthdayDate.getMonth(), 0);
      remainingDaysToNext += prevMonth.getDate();
  }
  if (monthsToNext < 0) {
      monthsToNext += 12;
  }

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const nextDayOfWeek = daysOfWeek[nextBirthdayDate.getDay()];

  return {
    years,
    months,
    days,
    totalMonths,
    totalWeeks,
    totalDays,
    totalHours,
    nextBirthday: {
      days: daysToNext, // Simplified total days
      months: monthsToNext, // Broken down
      dayOfWeek: nextDayOfWeek
    }
  };
};

export const isValidDate = (d: Date): boolean => {
  return d instanceof Date && !isNaN(d.getTime()) && d <= new Date();
};