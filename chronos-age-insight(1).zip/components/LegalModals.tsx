import React from 'react';
import { LegalPage } from '../types.ts';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: LegalPage;
}

export const LegalModal: React.FC<ModalProps> = ({ isOpen, onClose, type }) => {
  if (!isOpen || type === LegalPage.None) return null;

  const getContent = () => {
    switch (type) {
      case LegalPage.Privacy:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-800">Privacy Policy</h2>
            <p className="text-sm text-slate-600">Last updated: October 2023</p>
            <p><strong>1. Information Collection:</strong> Chronos Age Insight does not collect, store, or share any personal data entered into the calculator. All calculations are performed locally on your device.</p>
            <p><strong>2. Cookies:</strong> We may use cookies to analyze site traffic and optimize your experience. Third-party vendors, including Google, use cookies to serve ads based on a user's prior visits to your website or other websites.</p>
            <p><strong>3. Third-Party Links:</strong> Our website may contain links to third-party websites. We have no control over the privacy practices or the content of any of our business partners, advertisers, sponsors, or other websites to which we provide links.</p>
          </div>
        );
      case LegalPage.Terms:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-800">Terms of Service</h2>
            <p><strong>1. Acceptance of Terms:</strong> By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement.</p>
            <p><strong>2. Use License:</strong> Permission is granted to temporarily use the materials (information or software) on Chronos Age Insight's website for personal, non-commercial transitory viewing only.</p>
            <p><strong>3. Disclaimer:</strong> The materials on Chronos Age Insight's website are provided "as is". Chronos Age Insight makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties, including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
          </div>
        );
      case LegalPage.About:
        return (
           <div className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-800">About Us</h2>
            <p>Chronos Age Insight is dedicated to providing precise time calculations and historical context to your personal milestones.</p>
            <p>Our tool uses advanced algorithms to calculate accurate age metrics and leverages Artificial Intelligence to provide fun, historical context to your special day.</p>
            <p>Contact: support@chronos-example.com</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-fade-in">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto flex flex-col">
        <div className="p-6">
            {getContent()}
        </div>
        <div className="p-4 border-t border-slate-100 bg-slate-50 rounded-b-xl flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};