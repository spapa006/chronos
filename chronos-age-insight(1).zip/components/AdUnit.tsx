import React, { useEffect } from 'react';

interface AdUnitProps {
  className?: string;
  slotId?: string; // Optional: Pass specific slot IDs for different ad units
}

export const AdUnit: React.FC<AdUnitProps> = ({ className, slotId = "1234567890" }) => {
  useEffect(() => {
    // This pushes the ad to Google's queue once the component mounts
    try {
      // @ts-ignore
      if (window.adsbygoogle) {
        // @ts-ignore
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      }
    } catch (e) {
      console.error("AdSense error", e);
    }
  }, []);

  return (
    <div className={`w-full overflow-hidden bg-slate-100 rounded-lg flex items-center justify-center border-2 border-dashed border-slate-300 ${className}`}>
      {/* 
        -----------------------------------------------------
        PASTE YOUR ADSENSE CODE INSIDE THIS DIV 
        -----------------------------------------------------
        Example:
        <ins className="adsbygoogle"
             style={{ display: 'block', width: '100%' }}
             data-ad-client="ca-pub-YOUR_PUBLISHER_ID"
             data-ad-slot={slotId}
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
      */}
      
      {/* Visual Placeholder - Remove this span when you add the <ins> tag above */}
      <div className="p-8 text-center">
        <p className="text-slate-400 font-medium text-sm">AdSense Banner Area</p>
        <p className="text-slate-300 text-xs mt-1">(Replace this component with your ad code)</p>
      </div>
    </div>
  );
};