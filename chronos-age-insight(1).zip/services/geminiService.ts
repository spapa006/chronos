import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY;
// Safely initialize. If no key, we will handle it in the function.
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const getHistoricalInsights = async (date: Date): Promise<string> => {
  if (!ai) {
    console.warn("Gemini API Key not found");
    return "AI insights are unavailable at this time.";
  }

  const dateString = date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const year = date.getFullYear();

  const prompt = `
    I was born on ${dateString}. 
    Please generate a brief, engaging summary with the following sections in plain text (no markdown headings, just paragraphs):
    1. A fun fact about the year ${year}.
    2. A major historical event that shares this birthday (Month/Day).
    3. The "Generation" I belong to and a defining characteristic of it.
    
    Keep the tone celebratory and informative. Max 150 words.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text || "Could not generate insights.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to fetch historical data at this moment.";
  }
};